import firebase from "firebase";

var firebaseConfig = {
    apiKey: "AIzaSyBMwu4lhT3Y4iENO4Frrfh8WtlM7LILAxg",
    authDomain: "bfamily-films.firebaseapp.com",
    databaseURL: "https://bfamily-films.firebaseio.com",
    projectId: "bfamily-films",
    storageBucket: "bfamily-films.appspot.com",
    messagingSenderId: "366597884548",
    appId: "1:366597884548:web:fc514693b5adbb0cf9d0d1",
    measurementId: "G-XYC4XMXEEW"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
//   firebase.analytics();
export default firebase;